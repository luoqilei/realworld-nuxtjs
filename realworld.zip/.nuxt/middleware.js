const middleware = {}

middleware['notUser'] = require('../middleware/notUser.js')
middleware['notUser'] = middleware['notUser'].default || middleware['notUser']

middleware['user'] = require('../middleware/user.js')
middleware['user'] = middleware['user'].default || middleware['user']

export default middleware
