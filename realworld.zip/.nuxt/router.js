import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _02034164 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _2f6cfcce = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _211ef9ef = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _2e6f0aaf = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _30b25bdd = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _139730b2 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _15394dfc = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _02034164,
    children: [{
      path: "",
      component: _2f6cfcce,
      name: "home"
    }, {
      path: "/login",
      component: _211ef9ef,
      name: "login"
    }, {
      path: "/register",
      component: _211ef9ef,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _2e6f0aaf,
      name: "profile"
    }, {
      path: "/settings",
      component: _30b25bdd,
      name: "settings"
    }, {
      path: "/editor/:slug?",
      component: _139730b2,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _15394dfc,
      name: "article"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
